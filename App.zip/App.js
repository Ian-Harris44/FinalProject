// import React from "react"
// import Header from './components/Header'
// import Footer from './components/Footer'
// import Home from './components/Home'
// import About from './components/About'
// import americanBlackBear from './components/americanBlackBear'
// import asianBlackBear from './components/asianBlackBear'
// import Bear from './components/Bear'
// import brownBear from './components/brownBear'
// import giantPanda from './components/giantPanda'
// import kermodeBear from './components/kermodeBear'
// import polarBear from './components/polarBear'
// import slothBear from './components/slothBear'
// import spectacledBear from './components/spectacledBear'
// import sunBear from './components/sunBear'
// import tibetanBlueBear from './components/tibetanBlueBear'
// import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
// import data from './data'

// const App =()=> {
//     return(
//         <Router>
//             <Header />
//             <Routes>
//                 <Route exact path="/" element={<Home />} />
//                 <Route path="/Bear" element={<Bear />} />
//                 <Route path="/About" element={<About />} />
//                 <Route path="/americanBlackBear" element={<americanBlackBear />} />
//                 <Route path="/asianBlackBear" element={<asianBlackBear />} />
//                 <Route path="/brownBear" element={<brownBear />} />
//                 <Route path="/giantPanda" element={<giantPanda />} />
//                 <Route path="/kermodeBear" element={<kermodeBear />} />
//                 <Route path="/polarBear" element={<polarBear />} />
//                 <Route path="/slothBear" element={<slothBear />} />
//                 <Route path="/spectacledBear" element={<spectacledBear />} />
//                 <Route path="/sunBear" element={<sunBear />} />
//                 <Route path="/tibetanBlueBear" element={<tibetanBlueBear />} />
//             </Routes>
//             <Footer />
//         </Router>
//     )
// }

// export default App